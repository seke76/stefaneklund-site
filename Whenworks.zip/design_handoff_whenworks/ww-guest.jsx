function GuestLayout({ children }) {
  const { S, ev, lang } = useWW();
  return (
    <div className="flow">
      <aside className="flow-aside">
        <span className="invited"><Avatar name={ev.organizer || "?"} size={28}></Avatar>{S.g_invited(ev.organizer)}</span>
        <h1 className="display">{ev.title}</h1>
        {ev.desc && <p className="lede">{ev.desc}</p>}
        <dl className="meta">
          {ev.dur && <div><dt>{S.f_duration}</dt><dd>{ev.dur} {(ev.durUnit === "h" ? S.hours : S.days).toLowerCase()}</dd></div>}
          {ev.deadline && !ev.final && <div><dt>{S.reply_by}</dt><dd>{wwFmt.long(ev.deadline, lang)}</dd></div>}
        </dl>
      </aside>
      <section className="card">{children}</section>
    </div>
  );
}

function FinalBanner() {
  const { S, ev, lang } = useWW();
  if (!ev.final) return null;
  return <div className="final-banner"><span className="eyebrow">{S.g_final}</span><b>{wwFmt.slot(ev.final, lang)}</b>{ev.note && <span>{ev.note}</span>}<button className="btn btn-sm btn-ghost">{Ic.cal}{S.add_cal}</button></div>;
}

function ScreenGuestJoin() {
  const { S, ev, responses, go, guest, setGuest } = useWW();
  const pickExisting = (p) => { setGuest({ name: p.name, email: p.email || "", answers: { ...p.answers }, existing: true }); go("g-respond"); };
  return (
    <GuestLayout>
      <FinalBanner></FinalBanner>
      {ev.round > 1 && !ev.final && <div className="info-banner"><b>{S.g_new_round}</b><p>{ev.roundNote || S.g_new_round_d}</p></div>}
      <CardHead title={S.g_name} sub={S.g_name_d}></CardHead>
      <div className="fields">
        <Field label={S.f_name}><input className="inp" autoFocus value={guest.name} placeholder={S.g_name_ph} onChange={(e) => setGuest({ ...guest, name: e.target.value, existing: false })}></input></Field>
        <Field label={S.g_email} optional hint={S.g_email_d}><input className="inp" type="email" value={guest.email} placeholder="name@mail.com" onChange={(e) => setGuest({ ...guest, email: e.target.value })}></input></Field>
      </div>
      {responses.length > 0 && (
        <div className="returning">
          <span className="lbl">{S.g_returning}</span>
          <div className="chips">{responses.map((p) => <button key={p.name} className="chip chip-av" onClick={() => pickExisting(p)}><Avatar name={p.name} size={22}></Avatar>{p.name}</button>)}</div>
        </div>
      )}
      <Actions onNext={() => go("g-respond")} nextLabel={S.g_start} nextDisabled={!guest.name.trim()}></Actions>
    </GuestLayout>
  );
}

function ScreenGuestRespond() {
  const { S, ev, setEv, go, guest, setGuest, responses, setResponses, lang } = useWW();
  const slots = [...allSlots(ev)].sort((a, b) => (isNew(b, ev) ? 1 : 0) - (isNew(a, ev) ? 1 : 0));
  const [sd, setSd] = React.useState("");
  const [st, setSt] = React.useState("");
  const setA = (id, v) => setGuest({ ...guest, answers: { ...guest.answers, [id]: v } });
  const left = slots.filter((s) => !guest.answers[s.id]).length;
  const canSuggest = ev.mode === "open" || ev.allowSuggest;
  const addSuggestion = () => {
    const id = "x_" + sd + "_" + (st || "day");
    if (!slots.some((s) => s.id === id)) setEv({ ...ev, extra: [...ev.extra, { id, date: sd, time: st || null, by: guest.name }] });
    setA(id, "yes"); setSd(""); setSt("");
  };
  const send = () => {
    const me = { name: guest.name.trim(), email: guest.email, answers: guest.answers };
    setResponses([...responses.filter((p) => p.name.toLowerCase() !== me.name.toLowerCase()), me]);
    go("g-done");
  };
  return (
    <GuestLayout>
      <CardHead title={S.g_resp_title} sub={ev.mode === "open" ? S.g_resp_open : S.g_resp_fixed}></CardHead>
      <ul className="answer-list">
        {slots.map((s) => {
          const r = ev.showOthers ? tally(s, responses.filter((p) => p.name !== guest.name)) : { yes: [] };
          return (
            <li key={s.id} className={guest.answers[s.id] ? "answered " + guest.answers[s.id] : ""}>
              <div className="al-l"><SlotLabel s={s}></SlotLabel>{(r.yes.length > 0 || s.by || isNew(s, ev)) && <span className="al-meta">{isNew(s, ev) && <span className="new-pill">{S.new_tag}</span>}{s.by ? S.suggested_by(s.by) : ""}{s.by && r.yes.length ? " · " : ""}{r.yes.length ? r.yes.length + " " + S.can.toLowerCase() : ""}</span>}</div>
              <div className="yn">
                {[["yes", S.yes_l], ["maybe", S.maybe_l], ["no", S.no_l]].map(([v, l]) => (
                  <button key={v} className={"yn-b " + v + (guest.answers[s.id] === v ? " on" : "")} onClick={() => setA(s.id, v)} aria-pressed={guest.answers[s.id] === v}><Mark v={v}></Mark><span>{l}</span></button>
                ))}
              </div>
            </li>
          );
        })}
      </ul>
      {canSuggest && (
        <div className="suggest">
          <span className="lbl">{S.g_suggest}</span>
          <div className="row">
            <input className="inp inp-date" type="date" min={TODAY} value={sd} onChange={(e) => setSd(e.target.value)}></input>
            <input className="inp inp-time" type="time" value={st} onChange={(e) => setSt(e.target.value)}></input>
            <button className="btn btn-ghost" disabled={!sd} onClick={addSuggestion}>{Ic.plus}{S.g_add}</button>
          </div>
        </div>
      )}
      <div className="actions">
        <button className="btn btn-quiet" onClick={() => go("g-join")}>{Ic.arrowL}{S.back}</button>
        <div className="row">
          {left > 0 && <span className="muted small">{S.g_left(left)}</span>}
          <button className="btn btn-primary" onClick={send} disabled={left === slots.length}>{S.g_send}{Ic.arrowR}</button>
        </div>
      </div>
    </GuestLayout>
  );
}

function ScreenGuestDone() {
  const { S, go, guest, responses } = useWW();
  return (
    <GuestLayout>
      <FinalBanner></FinalBanner>
      <span className="badge">{Ic.check}</span>
      <CardHead title={S.g_done_title(guest.name.trim())} sub={S.g_done_sub}></CardHead>
      <div className="sub-block">
        <span className="lbl">{S.g_who} <em>{responses.length}</em></span>
        <div className="avs">{responses.map((p) => <span key={p.name} className="av-n"><Avatar name={p.name} size={26}></Avatar>{p.name}{p.name === guest.name.trim() ? " (" + S.you + ")" : ""}</span>)}</div>
      </div>
      <div className="actions"><span></span><button className="btn btn-ghost" onClick={() => go("g-respond")}>{S.g_edit}</button></div>
    </GuestLayout>
  );
}

Object.assign(window, { ScreenGuestJoin, ScreenGuestRespond, ScreenGuestDone });
