# Handoff: Whenworks – event scheduling app

## Overview
Whenworks helps an organizer find a time that works for a group. The organizer creates an event (What → When → Who), gets **one shared link** for all guests, and a **private organizer link**. Guests open the shared link, type their name and answer Yes / Maybe / No per proposed time. The organizer sees a named matrix of answers, can **ask again in new rounds** until a time works for everyone, and then confirms a final time. No accounts, no logins. Events auto-delete after 60 days.

UI languages: English and Swedish (toggle in header). Responsive: mobile-first, two-column layout ≥ 920px.

## About the Design Files
The files in this bundle are **design references created in HTML/React (in-browser Babel)**. They are prototypes that show the intended look and behavior. They are not production code. Recreate them in a real stack. No codebase exists yet, so choose a fitting one. Suggested: **Next.js (App Router) + TypeScript + Tailwind or CSS modules**, with **Postgres (e.g. Supabase/Neon) + Prisma/Drizzle**, and **Resend** (or similar) for the optional "time is set" email.

Open `Whenworks App.html` in a browser to click through. The Tweaks panel (toolbar toggle) jumps between screens and switches variants. Demo-only controls such as "Simulate round N answers" are prototype tooling. Do not ship them.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii and copy are final. Recreate pixel-close.
Chosen variants: **When picker = Calendar**, **Results = Table (matrix)**, **Accent = plum**. The "Week grid" and "Ranked" variants exist in the files as alternatives. Implement them only if asked.

## Routes (suggested)
- `/` – create flow (What / When / Who), client-side wizard
- `/e/[eventSlug]` – guest page (shared link)
- `/e/[eventSlug]/admin-[adminToken]` – organizer page (results, ask again, finalize)

The guest link is public to anyone who has it. The admin token is a separate unguessable secret (≥ 128 bits). Never expose it on the guest page.

## Screens

### Global shell
- Header: logo (34×34 plum rounded square, radius 10, italic serif "w" in Instrument Serif 26px, white) + "Whenworks" (Space Grotesk 18/700, -0.02em). Right side: role label (12px/600 uppercase, muted, letter-spacing .06em: "Organizer"/"Arrangör" or "Guest"/"Gäst") + EN/SV pill toggle (active = ink bg, white text).
- Max content width 1200px. Horizontal page padding `clamp(20px, 5vw, 56px)`. Main top padding `clamp(8px,3vw,32px)`, bottom `clamp(32px,5vw,64px)`.
- Footer: centered 12.5px muted: "No accounts. No tracking. Events delete themselves after 60 days." / "Inga konton. Ingen spårning. Event raderas automatiskt efter 60 dagar."
- Flow layout (create steps + guest pages): grid, ≥ 920px `5fr / 7fr` columns, gap 72px, left aside sticky (top 32px). Below 920px it stacks with gap `clamp(24px,4vw,40px)`.
- Aside: display headline (Instrument Serif 400, `clamp(40px,6vw,64px)`, line-height 1, -0.02em, text-wrap balance) + lede (17px muted, max 36ch) + step indicator.
- Card: bg `#FFFDF9`, 1px border `#E6DDD4`, radius 22, padding `clamp(22px,4vw,40px)`, shadow `0 1px 0 rgba(31,21,32,.03), 0 12px 40px -16px rgba(75,30,68,.14)`.
- Card head: h2 24/600 -0.025em, subtitle muted, 28px bottom margin.
- Actions row: top border 1px line, 24px padding-top, 32px margin-top, space-between. Back = quiet text button with ← icon. Primary = plum pill with → icon.

### 1. What (Vad)
Fields: Event title (required, placeholder only, **no prefilled value**), Short description (optional, textarea 3 rows), Duration (optional): segmented Hours/Days + numeric input 96px wide, placeholder "e.g. 2"/"t.ex. 2" + unit text. Continue is disabled until the title is non-empty.

### 2. When (När)
Two mode cards (radio-style, grid auto-fit min 220px):
- **I'll suggest times / Jag föreslår tider**: guests answer per slot.
- **Let guests suggest / Låt gästerna föreslå**: organizer picks a date range and guests mark days (slots = each day, time = null, "All day"/"Hela dagen").

Fixed mode, Calendar variant: two columns ≥ 720px. Left: month calendar (Monday first, past dates disabled, today ringed, dot under dates that have slots). Selecting a date shows time chips `09:00 12:00 15:00 18:00 19:00 20:00` + "Other" time input with a + button. Chips toggle slots. Right: "Your suggested times" list (date box + weekday + time, × remove). Toggle: "Guests can suggest other times".
Open mode: range calendar (first tap = start, second tap = end, in-between days tinted `--ac-soft`). Right: "N days selected" + start → end.
Continue is disabled until there is ≥ 1 slot or a range start.

### 3. Who (Vem)
Fields: Your name (required), Reply by (optional date). Toggles (switch + bold title + muted description):
- **Everyone needs to be there / Alla måste kunna**: enables the rounds flow (see Results).
- **Guests can see each other's answers / Deltagarna kan se varandras svar**: if off, guests don't see yes counts per slot. Only the organizer sees who can.
Below: "How inviting works" box (bg `#F6F1EA`, radius 16, three numbered lines). Primary: "Create event / Skapa event".

### 4. Event created (Ditt event är klart)
Green check badge (44px circle). Guest link in a copy box (mono 15px, Copy button → "Copied" green state for 1.6s). "Message to share" chat bubble (bg `--ac-soft`, radius 14 14 14 4, max 52ch) **with a Copy button below it**. Organizer link block (dashed border, lock icon, explanation, mono link **with Copy button**). There is **no** "See responses", "Share" or "Preview as guest" button on this screen. The user removed them on purpose.

Invite message EN: `{organizer} invited you to “{title}”. Mark the times that work for you: {link}`
SV: `{organizer} har bjudit in dig till ”{title}”. Markera tiderna som passar dig: {link}`

### 5. Guest – name (g-join)
Aside: "{organizer} invited you" pill with avatar, event title as display headline, description, meta (Duration, Reply by). Card: "What's your name?", name (required), email (optional, hint "We'll only email you when the time is set."). If others have answered: "Already answered? Pick your name" chips that load that person's answers for editing (one shared link, so identity = chosen name). If round > 1: info banner (bg `--ac-soft`) "New times added" + organizer's round note or default text. If the event is finalized: green banner with the final time + "Add to calendar".

### 6. Guest – answer (g-respond)
One row per slot (border 1.5px, radius 16). Left: date box + weekday/time. Optional meta: "New" pill, "Suggested by X", "N can" (only if showOthers). Right: segmented Yes / Maybe / No with status marks. Answered row tints: yes → `--yes-soft` with green border, maybe → `--maybe-soft`, no → bg. Current-round new slots are sorted first. If suggestions are allowed: "Suggest another time" (date + optional time + Add). That adds a slot `by: guestName` and auto-answers Yes. Footer: "N left to answer" + "Send answers" (disabled until ≥ 1 answer). Under 480px the Yes/Maybe/No control goes full width.

### 7. Guest – done (g-done)
"Thanks, {name}." + "Your answers are saved. Open the same link anytime to change them." + "Who's answered" list of name chips with "(you)". Button: "Change my answers".

### 8. Organizer – Results (Svar)
Header: eyebrow "Responses · Round N", title (display sm `clamp(34px,4.5vw,48px)`), "N people have answered · Reply by …". Tools: segmented Table/Ranked, "Ask for new times" (when the banner isn't shown), "Share link" (back to the created screen).
**Matrix**: sticky left name column (avatar + name), one column per slot (date box, weekday, time; "New" tag; "Suggested by"). Cells show marks: yes = solid green circle with check, maybe = amber ring with dash, no = soft red with ×, none = dashed ring. Footer rows: yes count (+maybe count) and a pick (✓) button per column. Highlighted column:
- If a slot has all yes → green column + tag "Everyone can / Alla kan".
- Else if mustAll → amber-tinted column (`#FBF4E6`) + tag "Closest / Närmast".
- Else → green column + tag "Best match".
Scoring: yes = 2, maybe = 1. Ties go to the earlier slot.
**mustAll and no full match** → amber banner (bg `#F8EDD8`, border `#E8D3AA`, radius 18): "No time works for all N yet." + "Closest: {slot}. Missing: names" + primary "Ask for new times".
**Full match and mustAll** → green banner "Everyone can: {slot}" + "Pick this time".
**Round just sent and no new answers yet** → info banner "Round N is out. Same link as before."

### 9. Organizer – Ask again (reask)
Card max 800px. Eyebrow "Round N+1". Sections:
1. "Closest so far": up to 3 top slots, each with chips for the people missing (mark + name).
2. "Times already asked": every current slot with "x of N" and Keep/Remove segmented control. Default Remove = slots that aren't closest and have ≥ 2 "no". Removed rows show strikethrough at 45% opacity.
3. "New times": the same calendar + time chip picker. Times already asked are disabled.
4. Toggle "Let guests suggest times too" (default on).
5. Note to guests (optional).
Primary: "Send round N+1" (disabled if there are no new times and suggestions are off). Effect: new slots are added with `round = N+1`, removed slots are hidden, `round++`, and earlier answers are kept. Guests see it through the same link.

### 10. Organizer – Confirm (finalize)
Chosen slot in an `--ac-soft` box + "Change". Lists of Can / Maybe / Can't with name chips. Optional note. Toggle "Email the N guests who left their address" (only if any did). Primary "Confirm time".

### 11. Final (Det är bestämt.)
Centered. Eyebrow = title, display "It's set." Plum block: weekday (13px uppercase), date (Instrument Serif `clamp(44px,8vw,64px)`), time · duration. Optional note. Copy box with message: `“{title}” is set for {slot}. See you there!`. "Add to calendar" (generate an .ics file).

## Data model
```ts
Event {
  id, slug (public), adminToken (secret),
  title, description?, durationValue?, durationUnit: 'h'|'d',
  mode: 'fixed'|'open', rangeStart?, rangeEnd?,
  organizerName, replyBy?, mustAll: boolean, showOthers: boolean,
  allowSuggest: boolean, round: number, roundNote?,
  finalSlotId?, finalNote?, createdAt, expiresAt (= createdAt + 60d)
}
Slot { id, eventId, date (ISO), time? ('HH:mm' | null = all day), round, suggestedBy?, removed: boolean }
Response { id, eventId, name (unique per event, case-insensitive), email?, updatedAt }
Answer { responseId, slotId, value: 'yes'|'maybe'|'no' }
```
In open mode, the day slots are derived from the range (or materialized as Slot rows with time = null).

## Behavior / rules
- One guest link per event. Guest identity = name. Re-submitting with the same name (case-insensitive) overwrites that response.
- `showOthers = false` → the guest API must not return other people's answers (enforce on the server, not only in the UI).
- Removed slots are kept in the DB but hidden. Answers stay.
- On finalize: set finalSlotId, and if notify is on, email the responses that have an email. The guest page then shows the final banner.
- Cron/TTL job deletes events after `expiresAt`.
- Copy buttons: clipboard write, then a 1.6s "Copied" state.
- Validation: title and organizer name are required. When needs ≥ 1 slot or a range. Guest name is required.

## Design tokens
Colors:
- `--ac` plum `#4B1E44`, `--ac-2` hover `#6B2C61`, `--ac-soft` `#F3E8F0`
- `--bg` `#F6F1EA` (page, input fill), `--paper` `#FFFDF9` (cards)
- `--ink` `#1F1520`, `--muted` `#6E6270`, `--line` `#E6DDD4`, `--line-2` `#D8CDC2`, placeholder `#A39AA4`
- `--yes` `#2D7A4C` / `--yes-soft` `#E1F0E6`; `--maybe` `#A86B12` / `--maybe-soft` `#F8EDD8`; `--no` `#A6413A` / `--no-soft` `#F6E4E1`
- Avatar fills (by name hash): `#E9D7E4 #DCE6D5 #F3E0C7 #D7DFEC #EED6D2 #E2DCEF`
- Alt accents (tweak only): forest `#1F4D3A/#2C6B51/#E3EFE8`, ink blue `#1E3354/#2C4A78/#E4EAF3`, terracotta `#B4472F/#C95A41/#F8E7E1`

Type: **Space Grotesk** 400–700 (UI, base 15px/1.5) and **Instrument Serif** 400 (display headlines, big date, logo "w" italic). Labels 13/600. Hints 12.5px. Eyebrows 12/600 uppercase, letter-spacing .08em, accent color. Use tabular numerals for times.
Radii: cards 22, sub-panels 16–18, inputs/date box 12, chips/buttons/pills 999.
Inputs: bg `--bg`, 1.5px transparent border, hover `--line-2`, focus `--ac` border + paper bg, padding 12×14, 16px text.
Buttons: min-height 46 (sm 36), padding 13×22, 15/600, active scale .97. Primary shadow `0 6px 18px -6px var(--ac)`.
Spacing: fields gap 22, sections 24–28, list gaps 8–10.

## Assets
No images. Icons are simple inline SVGs (arrow, check, ×, dash, plus, copy, calendar, lock) in `ww-ui.jsx`. Lucide equivalents are fine. Fonts come from Google Fonts.

## Files
- `Whenworks App.html` – entry point, global CSS (all tokens/classes), seed demo data, app state, Tweaks
- `ww-i18n.js` – all EN/SV copy (`WW_STR`) and date helpers (`wwFmt`, locale `en-GB`/`sv-SE`)
- `ww-ui.jsx` – shared components (Header, Steps, Field, Seg, Actions, Avatar, Mark, SlotLabel, CopyBox, CopyBtn, Calendar)
- `ww-organizer.jsx` – What, When, Who, Created, Results (matrix/ranked), Ask again, Finalize, Final, scoring (`tally`, `useBest`)
- `ww-guest.jsx` – guest join, respond, done
- `tweaks-panel.jsx` – prototype-only controls (do not port)
- `Whenworks standalone.html` – single-file offline version for viewing
