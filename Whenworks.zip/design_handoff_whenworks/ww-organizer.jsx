const TIMES = ["09:00", "12:00", "15:00", "18:00", "19:00", "20:00"];
const TODAY = "2026-10-03";

function allSlots(ev) {
  const base = ev.mode === "open" && ev.range.start ? wwFmt.range(ev.range.start, ev.range.end || ev.range.start).map((d) => ({ id: d, date: d, time: null })) : ev.slots;
  return [...base, ...(ev.added || []), ...ev.extra].filter((s) => !(ev.removed || []).includes(s.id)).sort((a, b) => (a.date + (a.time || "")).localeCompare(b.date + (b.time || "")));
}
function tally(slot, responses) {
  const r = { yes: [], maybe: [], no: [], none: [] };
  responses.forEach((p) => r[p.answers[slot.id] || "none"].push(p.name));
  r.score = r.yes.length * 2 + r.maybe.length;
  return r;
}

function FlowLayout({ step, children }) {
  const { S } = useWW();
  return (
    <div className="flow">
      <aside className="flow-aside">
        <h1 className="display">{S.tagline}</h1>
        <p className="lede">{S.tagline_p}</p>
        <Steps current={step}></Steps>
      </aside>
      <section className="card">{children}</section>
    </div>
  );
}

function ScreenWhat() {
  const { S, ev, setEv, go } = useWW();
  const set = (k, v) => setEv({ ...ev, [k]: v });
  return (
    <FlowLayout step={1}>
      <CardHead title={S.what_title} sub={S.what_sub}></CardHead>
      <div className="fields">
        <Field label={S.f_title}><input className="inp" value={ev.title} placeholder={S.f_title_ph} onChange={(e) => set("title", e.target.value)}></input></Field>
        <Field label={S.f_desc} optional><textarea className="inp" rows="3" value={ev.desc} placeholder={S.f_desc_ph} onChange={(e) => set("desc", e.target.value)}></textarea></Field>
        <Field label={S.f_duration} optional>
          <div className="row">
            <Seg value={ev.durUnit} onChange={(v) => set("durUnit", v)} options={[{ v: "h", l: S.hours }, { v: "d", l: S.days }]}></Seg>
            <input className="inp inp-num" inputMode="numeric" value={ev.dur} placeholder={S.f_dur_ph} onChange={(e) => set("dur", e.target.value.replace(/\D/g, ""))}></input>
            <span className="muted">{ev.durUnit === "h" ? S.hours.toLowerCase() : S.days.toLowerCase()}</span>
          </div>
        </Field>
      </div>
      <Actions onNext={() => go("when")} nextDisabled={!ev.title.trim()}></Actions>
    </FlowLayout>
  );
}

function WhenCalendar({ slots, setSlots, taken = [], label }) {
  const { S, lang } = useWW();
  const [month, setMonth] = React.useState({ y: 2026, m: 9 });
  const [sel, setSel] = React.useState(slots[0] ? slots[0].date : null);
  const [other, setOther] = React.useState("");
  const has = (d, t) => slots.some((s) => s.date === d && s.time === t);
  const isTaken = (d, t) => taken.some((s) => s.date === d && s.time === t);
  const toggle = (d, t) => setSlots(has(d, t) ? slots.filter((s) => !(s.date === d && s.time === t)) : [...slots, { id: d + "_" + t, date: d, time: t }]);
  const sorted = [...slots].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  return (
    <div className="when-cal">
      <div>
        <Calendar month={month} setMonth={setMonth} minDate={TODAY} onPick={setSel} isOn={(c) => c === sel} dots={(c) => slots.filter((s) => s.date === c).length}></Calendar>
        {sel && (
          <div className="time-pick">
            <span className="lbl">{S.times_on} · {wwFmt.long(sel, lang)}</span>
            <div className="chips">
              {TIMES.map((t) => <button key={t} disabled={isTaken(sel, t)} className={"chip" + (has(sel, t) ? " on" : "")} onClick={() => toggle(sel, t)}>{t}</button>)}
              <span className="chip-other"><input type="time" value={other} onChange={(e) => setOther(e.target.value)} aria-label={S.other_time}></input><button className="chip" disabled={!other} onClick={() => { if (!has(sel, other) && !isTaken(sel, other)) toggle(sel, other); setOther(""); }}>{Ic.plus}</button></span>
            </div>
          </div>
        )}
      </div>
      <div className="slot-col">
        <span className="lbl">{label || S.your_slots} <em>{sorted.length}</em></span>
        {sorted.length === 0 ? <p className="empty">{S.no_slots}</p> : (
          <ul className="slot-list">
            {sorted.map((s) => <li key={s.id}><SlotLabel s={s}></SlotLabel><button className="icon-btn" aria-label="Remove" onClick={() => toggle(s.date, s.time)}>{Ic.x}</button></li>)}
          </ul>
        )}
      </div>
    </div>
  );
}

function WhenGrid({ slots, setSlots }) {
  const { S, lang } = useWW();
  const days = [...Array(14)].map((_, i) => wwFmt.addDays(TODAY, i + 1));
  const has = (d, t) => slots.some((s) => s.date === d && s.time === t);
  const toggle = (d, t) => setSlots(has(d, t) ? slots.filter((s) => !(s.date === d && s.time === t)) : [...slots, { id: d + "_" + t, date: d, time: t }]);
  return (
    <div>
      <div className="tgrid-wrap">
        <table className="tgrid">
          <thead><tr><th></th>{days.map((d) => <th key={d}><span>{wwFmt.day(d, lang)}</span><b>{wwFmt.num(d)}</b></th>)}</tr></thead>
          <tbody>{TIMES.map((t) => <tr key={t}><th>{t}</th>{days.map((d) => <td key={d}><button className={has(d, t) ? "on" : ""} onClick={() => toggle(d, t)} aria-label={d + " " + t}>{has(d, t) && Ic.check}</button></td>)}</tr>)}</tbody>
        </table>
      </div>
      <p className="muted small" style={{ marginTop: 12 }}>{S.your_slots}: {slots.length}</p>
    </div>
  );
}

function WhenRange() {
  const { S, ev, setEv } = useWW();
  const [month, setMonth] = React.useState({ y: 2026, m: 9 });
  const { start, end } = ev.range;
  const pick = (c) => {
    if (!start || (start && end) || c < start) setEv({ ...ev, range: { start: c, end: null } });
    else setEv({ ...ev, range: { start, end: c } });
  };
  const n = start ? wwFmt.range(start, end || start).length : 0;
  return (
    <div className="when-cal">
      <Calendar month={month} setMonth={setMonth} minDate={TODAY} onPick={pick} isOn={(c) => c === start || c === end} isMid={(c) => start && end && c > start && c < end}></Calendar>
      <div className="slot-col">
        <span className="lbl">{n ? S.range_sel(n) : S.range_hint}</span>
        {start && <div className="range-sum"><SlotLabel s={{ date: start }} compact></SlotLabel><span className="muted">→</span><SlotLabel s={{ date: end || start }} compact></SlotLabel></div>}
      </div>
    </div>
  );
}

function ScreenWhen() {
  const { S, ev, setEv, go, t } = useWW();
  const ok = ev.mode === "open" ? !!ev.range.start : ev.slots.length > 0;
  return (
    <FlowLayout step={2}>
      <CardHead title={S.when_title} sub={S.when_sub}></CardHead>
      <div className="mode-cards">
        {[["fixed", S.mode_fixed, S.mode_fixed_d], ["open", S.mode_open, S.mode_open_d]].map(([m, l, d]) => (
          <button key={m} className={"mode" + (ev.mode === m ? " on" : "")} onClick={() => setEv({ ...ev, mode: m })}>
            <span className="radio"></span><span><b>{l}</b><span>{d}</span></span>
          </button>
        ))}
      </div>
      {ev.mode === "fixed" ? (t.whenStyle === "grid" ? <WhenGrid slots={ev.slots} setSlots={(v) => setEv({ ...ev, slots: v })}></WhenGrid> : <WhenCalendar slots={ev.slots} setSlots={(v) => setEv({ ...ev, slots: v })}></WhenCalendar>) : <WhenRange></WhenRange>}
      {ev.mode === "fixed" && (
        <label className="toggle-row"><input type="checkbox" checked={ev.allowSuggest} onChange={(e) => setEv({ ...ev, allowSuggest: e.target.checked })}></input><span className="sw"></span>{S.allow_suggest}</label>
      )}
      <Actions onBack={() => go("what")} onNext={() => go("who")} nextDisabled={!ok}></Actions>
    </FlowLayout>
  );
}

function ScreenWho() {
  const { S, ev, setEv, go } = useWW();
  return (
    <FlowLayout step={3}>
      <CardHead title={S.who_title} sub={S.who_sub}></CardHead>
      <div className="fields">
        <Field label={S.f_name}><input className="inp" value={ev.organizer} placeholder={S.f_name_ph} onChange={(e) => setEv({ ...ev, organizer: e.target.value })}></input></Field>
        <Field label={S.f_deadline} optional><input className="inp inp-date" type="date" min={TODAY} value={ev.deadline} onChange={(e) => setEv({ ...ev, deadline: e.target.value })}></input></Field>
      </div>
      <label className="toggle-row"><input type="checkbox" checked={ev.mustAll} onChange={(e) => setEv({ ...ev, mustAll: e.target.checked })}></input><span className="sw"></span><span className="tg-t"><b>{S.must_all}</b><span>{S.must_all_d}</span></span></label>
      <label className="toggle-row"><input type="checkbox" checked={ev.showOthers} onChange={(e) => setEv({ ...ev, showOthers: e.target.checked })}></input><span className="sw"></span><span className="tg-t"><b>{S.show_others}</b><span>{S.show_others_d}</span></span></label>
      <div className="how">
        <span className="lbl">{S.how_title}</span>
        <ol>{S.how.map((h, i) => <li key={i}><span className="n">{i + 1}</span>{h}</li>)}</ol>
      </div>
      <Actions onBack={() => go("when")} onNext={() => go("created")} nextLabel={S.create} nextDisabled={!ev.organizer.trim()}></Actions>
    </FlowLayout>
  );
}

function ScreenCreated() {
  const { S, ev, go, setRole } = useWW();
  const link = "whenworks.app/e/k7f2qx";
  return (
    <div className="single">
      <section className="card card-wide">
        <span className="badge">{Ic.check}</span>
        <CardHead title={S.created_title} sub={S.created_sub}></CardHead>
        <CopyBox text={link} mono></CopyBox>
        <div className="sub-block">
          <span className="lbl">{S.share_msg}</span>
          <div className="msg-wrap"><div className="msg">{S.invite_msg(ev.organizer, ev.title, "https://" + link)}</div><CopyBtn text={S.invite_msg(ev.organizer, ev.title, "https://" + link)}></CopyBtn></div>
        </div>
        <div className="admin">
          <span className="admin-ic">{Ic.lock}</span>
          <div><b>{S.admin_title}</b><p>{S.admin_d}</p><div className="admin-link"><code>whenworks.app/e/k7f2qx/admin-9Hc3</code><CopyBtn text="https://whenworks.app/e/k7f2qx/admin-9Hc3"></CopyBtn></div></div>
        </div>
      </section>
    </div>
  );
}

const isNew = (s, ev) => ev.round > 1 && (s.round || 1) === ev.round;
const missingOf = (r) => [...r.maybe.map((n) => [n, "maybe"]), ...r.no.map((n) => [n, "no"]), ...r.none.map((n) => [n, "none"])];
function useBest(slots) {
  const { ev, responses } = useWW();
  const ranked = slots.map((s) => ({ s, r: tally(s, responses) })).sort((a, b) => b.r.score - a.r.score);
  const n = responses.length;
  const full = ranked.find((x) => n > 0 && x.r.yes.length === n);
  const maxYes = ranked.length ? Math.max(...ranked.map((x) => x.r.yes.length)) : 0;
  const closest = ranked.filter((x) => maxYes > 0 && x.r.yes.length === maxYes).slice(0, 3);
  return { ranked, full, closest, best: full ? full.s : ranked[0] && ranked[0].s, tag: full ? "all" : ev.mustAll ? "closest" : "best", n };
}

function ResultsMatrix({ slots, B, onPick }) {
  const { S, responses, ev } = useWW();
  const best = B.best;
  const cls = (s) => (best && s.id === best.id ? (B.tag === "closest" ? "close" : "best") : "");
  const tagTxt = { all: S.all_can, closest: S.closest, best: S.best }[B.tag];
  return (
    <div className="mx-wrap">
      <table className="mx">
        <thead>
          <tr><th className="pcol"></th>{slots.map((s) => <th key={s.id} className={cls(s)}>{best && s.id === best.id && <span className={"best-tag " + B.tag}>{tagTxt}</span>}<SlotLabel s={s} compact></SlotLabel>{isNew(s, ev) && <span className="by new">{S.new_tag}</span>}{s.by && <span className="by">{S.suggested_by(s.by)}</span>}</th>)}</tr>
        </thead>
        <tbody>
          {responses.map((p) => <tr key={p.name}><th className="pcol"><Avatar name={p.name} size={28}></Avatar><span>{p.name}</span></th>{slots.map((s) => <td key={s.id} className={cls(s)}><Mark v={p.answers[s.id]}></Mark></td>)}</tr>)}
        </tbody>
        <tfoot>
          <tr><th className="pcol">{S.can}</th>{slots.map((s) => { const r = tally(s, responses); return <td key={s.id} className={cls(s)}><b>{r.yes.length}</b><span className="muted">{r.maybe.length ? " +" + r.maybe.length : ""}</span></td>; })}</tr>
          <tr><th className="pcol"></th>{slots.map((s) => <td key={s.id} className={cls(s)}><button className="btn btn-sm btn-pick" aria-label={S.pick_this} onClick={() => onPick(s)}>{Ic.check}</button></td>)}</tr>
        </tfoot>
      </table>
    </div>
  );
}

function ResultsRanked({ B, onPick }) {
  const { S, responses, ev } = useWW();
  const n = responses.length || 1;
  const tagTxt = { all: S.all_can, closest: S.closest, best: S.best }[B.tag];
  return (
    <ol className="rank">
      {B.ranked.map(({ s, r }, i) => (
        <li key={s.id} className={i === 0 ? "top " + B.tag : ""}>
          <div className="rank-head">
            <SlotLabel s={s}></SlotLabel>
            {i === 0 && <span className={"best-tag " + B.tag}>{tagTxt}</span>}
            {isNew(s, ev) && <span className="new-pill">{S.new_tag}</span>}
            <span className="rank-n"><b>{r.yes.length}</b> {S.of} {responses.length}</span>
            <button className="btn btn-sm btn-ghost" onClick={() => onPick(s)}>{S.pick_this}</button>
          </div>
          <div className="bar"><span className="b-yes" style={{ width: (r.yes.length / n) * 100 + "%" }}></span><span className="b-maybe" style={{ width: (r.maybe.length / n) * 100 + "%" }}></span></div>
          <div className="who">
            {[["yes", S.can], ["maybe", S.maybe], ["no", S.cant], ["none", S.noans]].filter(([k]) => r[k].length).map(([k, l]) => (
              <span key={k} className={"who-g " + k}><Mark v={k}></Mark>{l}: {r[k].join(", ")}</span>
            ))}
          </div>
          {s.by && <span className="by">{S.suggested_by(s.by)}</span>}
        </li>
      ))}
    </ol>
  );
}

function ScreenResults() {
  const { S, ev, responses, go, t, setPicked, lang } = useWW();
  const [view, setView] = React.useState(t.resultsView);
  React.useEffect(() => setView(t.resultsView), [t.resultsView]);
  const slots = allSlots(ev);
  const B = useBest(slots);
  const onPick = (s) => { setPicked(s); go("finalize"); };
  const curNew = slots.filter((s) => isNew(s, ev));
  const waiting = curNew.length > 0 && !responses.some((p) => curNew.some((s) => p.answers[s.id]));
  const needMore = ev.mustAll && !B.full && responses.length > 0;
  const c = B.closest[0];
  return (
    <div className="results">
      <div className="res-head">
        <div>
          <span className="eyebrow">{S.results_title}{ev.round > 1 ? " · " + S.round(ev.round) : ""}</span>
          <h1 className="display sm">{ev.title}</h1>
          <p className="muted">{S.n_resp(responses.length)}{ev.deadline ? " · " + S.reply_by + " " + wwFmt.long(ev.deadline, lang) : ""}</p>
        </div>
        <div className="res-tools">
          <Seg value={view} onChange={setView} options={[{ v: "matrix", l: S.view_matrix }, { v: "ranked", l: S.view_ranked }]}></Seg>
          {!needMore && <button className="btn btn-sm btn-ghost" onClick={() => go("reask")}>{S.ask_again}</button>}
          <button className="btn btn-sm btn-ghost" onClick={() => go("created")}>{S.share_again}</button>
        </div>
      </div>
      {waiting && <div className="info-banner">{S.round_live(ev.round)}</div>}
      {needMore && !waiting && (
        <div className="reask-banner">
          <div className="rb-t">
            <b>{S.no_full(responses.length)}</b>
            {c && <span>{S.closest}: <strong>{wwFmt.slot(c.s, lang)}</strong>. {S.missing}: {missingOf(c.r).map(([n]) => n).join(", ")}</span>}
          </div>
          <button className="btn btn-primary" onClick={() => go("reask")}>{S.ask_again}{Ic.arrowR}</button>
        </div>
      )}
      {ev.mustAll && B.full && (
        <div className="full-banner"><Mark v="yes"></Mark><b>{S.all_can}: {wwFmt.slot(B.full.s, lang)}</b><button className="btn btn-sm btn-primary" onClick={() => onPick(B.full.s)}>{S.pick_this}</button></div>
      )}
      <section className="card card-flush">
        {view === "matrix" ? <ResultsMatrix slots={slots} B={B} onPick={onPick}></ResultsMatrix> : <ResultsRanked B={B} onPick={onPick}></ResultsRanked>}
      </section>
      <div className="legend"><span><Mark v="yes"></Mark>{S.can}</span><span><Mark v="maybe"></Mark>{S.maybe}</span><span><Mark v="no"></Mark>{S.cant}</span></div>
    </div>
  );
}

function ScreenReask() {
  const { S, ev, setEv, responses, go } = useWW();
  const slots = allSlots(ev);
  const B = useBest(slots);
  const closeIds = B.closest.map((x) => x.s.id);
  const [removed, setRemoved] = React.useState(() => slots.filter((s) => !closeIds.includes(s.id) && tally(s, responses).no.length >= 2).map((s) => s.id));
  const [fresh, setFresh] = React.useState([]);
  const [note, setNote] = React.useState("");
  const [sugg, setSugg] = React.useState(true);
  const next = ev.round + 1;
  const send = () => {
    setEv({ ...ev, added: [...ev.added, ...fresh.map((s) => ({ ...s, round: next }))], removed: [...ev.removed, ...removed], round: next, allowSuggest: sugg, roundNote: note });
    go("results");
  };
  return (
    <div className="single">
      <section className="card card-wide card-xl">
        <span className="eyebrow">{S.round(next)}</span>
        <CardHead title={S.reask_title} sub={S.reask_sub}></CardHead>
        {B.closest.length > 0 && !B.full && (
          <div className="section">
            <span className="lbl">{S.blockers}</span>
            <ul className="close-list">
              {B.closest.map(({ s, r }) => (
                <li key={s.id}>
                  <SlotLabel s={s}></SlotLabel>
                  <div className="avs">{missingOf(r).map(([n, k]) => <span key={n} className={"av-n miss " + k}><Mark v={k}></Mark>{n}</span>)}</div>
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="section">
          <span className="lbl">{S.prev_slots}</span>
          <ul className="slot-list prev-list">
            {slots.map((s) => {
              const r = tally(s, responses); const off = removed.includes(s.id);
              return (
                <li key={s.id} className={off ? "off" : ""}>
                  <SlotLabel s={s}></SlotLabel>
                  <span className="muted small pl-n">{r.yes.length} {S.of} {responses.length}</span>
                  <Seg value={off ? "rm" : "keep"} onChange={(v) => setRemoved(v === "rm" ? [...removed, s.id] : removed.filter((x) => x !== s.id))} options={[{ v: "keep", l: S.keep }, { v: "rm", l: S.remove }]}></Seg>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="section">
          <WhenCalendar slots={fresh} setSlots={setFresh} taken={slots} label={S.new_slots}></WhenCalendar>
        </div>
        <label className="toggle-row"><input type="checkbox" checked={sugg} onChange={(e) => setSugg(e.target.checked)}></input><span className="sw"></span>{S.let_suggest}</label>
        <div className="fields section">
          <Field label={S.f_note} optional><textarea className="inp" rows="2" value={note} placeholder={S.f_round_note_ph} onChange={(e) => setNote(e.target.value)}></textarea></Field>
        </div>
        <Actions onBack={() => go("results")} onNext={send} nextLabel={S.send_round(next)} nextDisabled={fresh.length === 0 && !sugg}></Actions>
      </section>
    </div>
  );
}

function ScreenFinalize() {
  const { S, ev, responses, picked, go, lang, setEv } = useWW();
  const [note, setNote] = React.useState("");
  const [notify, setNotify] = React.useState(true);
  if (!picked) return null;
  const r = tally(picked, responses);
  const nEmail = responses.filter((p) => p.email).length;
  return (
    <div className="single">
      <section className="card card-wide">
        <CardHead title={S.finalize_title} sub={S.finalize_sub}></CardHead>
        <div className="final-slot">
          <SlotLabel s={picked}></SlotLabel>
          <button className="btn btn-sm btn-quiet" onClick={() => go("results")}>{S.change}</button>
        </div>
        <div className="who-list">
          {[["yes", S.can], ["maybe", S.maybe], ["no", S.cant]].map(([k, l]) => r[k].length > 0 && (
            <div key={k} className="who-row"><span className={"who-l " + k}><Mark v={k}></Mark>{l}</span><div className="avs">{r[k].map((n) => <span key={n} className="av-n"><Avatar name={n} size={26}></Avatar>{n}</span>)}</div></div>
          ))}
        </div>
        <div className="fields">
          <Field label={S.f_note} optional><textarea className="inp" rows="2" value={note} placeholder={S.f_note_ph} onChange={(e) => setNote(e.target.value)}></textarea></Field>
        </div>
        {nEmail > 0 && <label className="toggle-row"><input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)}></input><span className="sw"></span>{S.notify(nEmail)}</label>}
        <Actions onBack={() => go("results")} onNext={() => { setEv({ ...ev, final: picked, note }); go("final"); }} nextLabel={S.confirm}></Actions>
      </section>
    </div>
  );
}

function ScreenFinal() {
  const { S, ev, lang } = useWW();
  const f = ev.final;
  if (!f) return null;
  return (
    <div className="single">
      <section className="card card-wide final">
        <span className="eyebrow">{ev.title}</span>
        <h1 className="display">{S.final_title}</h1>
        <div className="big-date">
          <span className="bd-day">{wwFmt.d(f.date).toLocaleDateString(wwFmt.loc(lang), { weekday: "long" })}</span>
          <span className="bd-main">{wwFmt.d(f.date).toLocaleDateString(wwFmt.loc(lang), { day: "numeric", month: "long" })}</span>
          <span className="bd-time">{f.time || S.whole_day}{f.time && ev.dur ? " · " + ev.dur + " " + (ev.durUnit === "h" ? S.hours : S.days).toLowerCase() : ""}</span>
        </div>
        {ev.note && <p className="note">{ev.note}</p>}
        <p className="muted">{S.final_sub}</p>
        <CopyBox text={S.final_msg(ev.title, wwFmt.slot(f, lang))}></CopyBox>
        <div className="actions"><span></span><button className="btn btn-ghost">{Ic.cal}{S.add_cal}</button></div>
      </section>
    </div>
  );
}

Object.assign(window, { isNew, ScreenReask, allSlots, tally, TODAY, TIMES, ScreenWhat, ScreenWhen, ScreenWho, ScreenCreated, ScreenResults, ScreenFinalize, ScreenFinal });
