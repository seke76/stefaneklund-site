const WWCtx = React.createContext(null);
const useWW = () => React.useContext(WWCtx);

const Ic = {
  arrowL: <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 3L5 8l5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"></path></svg>,
  arrowR: <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M6 3l5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"></path></svg>,
  check: <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8.5l3 3 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path></svg>,
  x: <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"></path></svg>,
  q: <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M3 8h10" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"></path></svg>,
  plus: <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"></path></svg>,
  copy: <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="5" y="5" width="8.5" height="8.5" rx="2" stroke="currentColor" strokeWidth="1.5"></rect><path d="M10.5 2.5h-6a2 2 0 00-2 2v6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path></svg>,
  cal: <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2" y="3" width="12" height="11" rx="2" stroke="currentColor" strokeWidth="1.5"></rect><path d="M2 6.5h12M5.5 1.5v3M10.5 1.5v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path></svg>,
  lock: <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="3" y="7" width="10" height="7" rx="2" stroke="currentColor" strokeWidth="1.5"></rect><path d="M5.5 7V5a2.5 2.5 0 015 0v2" stroke="currentColor" strokeWidth="1.5"></path></svg>
};

function Logo() {
  return <div className="brand"><span className="logo">w</span><span>Whenworks</span></div>;
}

function Header() {
  const { lang, setLang, role } = useWW();
  const S = WW_STR[lang];
  return (
    <header className="ww-header">
      <Logo></Logo>
      <div className="hdr-r">
        <span className="role-tag">{role === "guest" ? S.role_guest : S.role_org}</span>
        <div className="lang">
          {["en", "sv"].map((l) => <button key={l} className={lang === l ? "on" : ""} onClick={() => setLang(l)}>{l.toUpperCase()}</button>)}
        </div>
      </div>
    </header>
  );
}

function Footer() {
  const { S } = useWW();
  return <footer className="ww-footer">{S.footer}</footer>;
}

function Steps({ current }) {
  const { S } = useWW();
  const items = [S.step_what, S.step_when, S.step_who];
  return (
    <ol className="steps">
      {items.map((s, i) => (
        <li key={i} className={i + 1 === current ? "on" : i + 1 < current ? "done" : ""}>
          <span className="n">{i + 1 < current ? Ic.check : i + 1}</span><span>{s}</span>
        </li>
      ))}
    </ol>
  );
}

function CardHead({ title, sub }) {
  return <div className="card-head"><h2>{title}</h2>{sub && <p>{sub}</p>}</div>;
}

function Field({ label, optional, hint, children }) {
  const { S } = useWW();
  return (
    <label className="field">
      <span className="lbl">{label}{optional && <em> ({S.optional})</em>}</span>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </label>
  );
}

function Seg({ value, options, onChange }) {
  return (
    <div className="seg">
      {options.map((o) => <button type="button" key={o.v} className={value === o.v ? "on" : ""} onClick={() => onChange(o.v)}>{o.l}</button>)}
    </div>
  );
}

function Actions({ onBack, onNext, nextLabel, nextDisabled }) {
  const { S } = useWW();
  return (
    <div className="actions">
      {onBack ? <button className="btn btn-quiet" onClick={onBack}>{Ic.arrowL}{S.back}</button> : <span></span>}
      <button className="btn btn-primary" disabled={nextDisabled} onClick={onNext}>{nextLabel || S.cont}{Ic.arrowR}</button>
    </div>
  );
}

const AV_COLORS = ["#E9D7E4", "#DCE6D5", "#F3E0C7", "#D7DFEC", "#EED6D2", "#E2DCEF"];
function Avatar({ name, size = 32 }) {
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 997;
  return <span className="av" title={name} style={{ width: size, height: size, fontSize: size * 0.42, background: AV_COLORS[h % AV_COLORS.length] }}>{name.slice(0, 1).toUpperCase()}</span>;
}

function Mark({ v }) {
  if (v === "yes") return <span className="mk yes">{Ic.check}</span>;
  if (v === "maybe") return <span className="mk maybe">{Ic.q}</span>;
  if (v === "no") return <span className="mk no">{Ic.x}</span>;
  return <span className="mk none"></span>;
}

function SlotLabel({ s, compact }) {
  const { lang, S } = useWW();
  return (
    <span className={"slot-lbl" + (compact ? " compact" : "")}>
      <span className="dbox"><b>{wwFmt.num(s.date)}</b><i>{wwFmt.mon(s.date, lang)}</i></span>
      <span className="st"><b>{wwFmt.day(s.date, lang)}</b><span>{s.time || S.whole_day}</span></span>
    </span>
  );
}

function CopyBox({ text, mono }) {
  const { S } = useWW();
  const [ok, setOk] = React.useState(false);
  const copy = () => { navigator.clipboard && navigator.clipboard.writeText(text).catch(() => {}); setOk(true); setTimeout(() => setOk(false), 1600); };
  return (
    <div className={"copybox" + (mono ? " mono" : "")}>
      <span className="txt">{text}</span>
      <button className={"btn btn-sm " + (ok ? "btn-ok" : "btn-dark")} onClick={copy}>{ok ? Ic.check : Ic.copy}{ok ? S.copied : S.copy}</button>
    </div>
  );
}

function CopyBtn({ text }) {
  const { S } = useWW();
  const [ok, setOk] = React.useState(false);
  const copy = () => { navigator.clipboard && navigator.clipboard.writeText(text).catch(() => {}); setOk(true); setTimeout(() => setOk(false), 1600); };
  return <button className={"btn btn-sm " + (ok ? "btn-ok" : "btn-dark")} onClick={copy}>{ok ? Ic.check : Ic.copy}{ok ? S.copied : S.copy}</button>;
}

function Calendar({ month, setMonth, isOn, isMid, onPick, minDate, dots }) {
  const { lang } = useWW();
  const first = new Date(month.y, month.m, 1);
  const startPad = (first.getDay() + 6) % 7;
  const nDays = new Date(month.y, month.m + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startPad; i++) cells.push(null);
  for (let d = 1; d <= nDays; d++) cells.push(wwFmt.iso(new Date(month.y, month.m, d)));
  const wd = [...Array(7)].map((_, i) => new Date(2026, 9, 5 + i).toLocaleDateString(wwFmt.loc(lang), { weekday: "narrow" }));
  const shift = (n) => { const x = new Date(month.y, month.m + n, 1); setMonth({ y: x.getFullYear(), m: x.getMonth() }); };
  return (
    <div className="cal">
      <div className="cal-top">
        <b>{first.toLocaleDateString(wwFmt.loc(lang), { month: "long", year: "numeric" })}</b>
        <div className="cal-nav"><button onClick={() => shift(-1)} aria-label="Previous">{Ic.arrowL}</button><button onClick={() => shift(1)} aria-label="Next">{Ic.arrowR}</button></div>
      </div>
      <div className="cal-grid">
        {wd.map((w, i) => <span key={"w" + i} className="wd">{w}</span>)}
        {cells.map((c, i) => c ? (
          <button key={c} disabled={c < minDate} onClick={() => onPick(c)}
            className={"cd" + (isOn(c) ? " on" : "") + (isMid && isMid(c) ? " mid" : "") + (c === minDate ? " today" : "")}>
            {wwFmt.num(c)}{dots && dots(c) > 0 && <i className="dot"></i>}
          </button>
        ) : <span key={"e" + i}></span>)}
      </div>
    </div>
  );
}

Object.assign(window, { WWCtx, useWW, Ic, Logo, Header, Footer, Steps, CardHead, Field, Seg, Actions, Avatar, Mark, SlotLabel, CopyBox, CopyBtn, Calendar });
